package com.hyphenate.chatdemo.callkit.views

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.widget.ImageView
import android.widget.TextView
import com.hyphenate.chatdemo.R
import com.hyphenate.callkit.bean.CallType
import com.hyphenate.callkit.bean.Constant
import com.hyphenate.easeui.common.ChatTextMessageBody
import com.hyphenate.easeui.widget.chatrow.ChatUIKitRow

@SuppressLint("ViewConstructor")
class ChatRowConferenceInvite @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    isSender: Boolean
) : ChatUIKitRow(context, attrs, defStyleAttr, isSender) {
    protected val contentView: TextView? by lazy { findViewById(R.id.tv_chatcontent) }
    private val ivCallIcon: ImageView by lazy { findViewById(R.id.iv_call_icon) }
    override fun onInflateView() {
        inflater.inflate(
            if (!isSender) R.layout.demo_row_received_conference_invite else R.layout.demo_row_sent_conference_invite,
            this
        )
    }

    override fun onSetUpView() {
        (message?.body as? ChatTextMessageBody)?.let {
            var message = it.message
            if (message.isNullOrEmpty().not() && message.contains("-")) {
                message = """
                ${message.substring(0, message.indexOf("-") + 1)}
                ${message.substring(message.indexOf("-") + 1)}
                """.trimIndent()
            }
            contentView?.text = message
        }
        message?.let {
            ivCallIcon.setImageResource(R.drawable.d_chat_video_call_self)
        }
    }

}
