package com.hyphenate.chatdemo.common

object DemoConstant {
    const val SKIP_DEVELOPER_CONFIG = "skip_developer_config"
    const val CALL_INVITE_MESSAGE = "call_invite_message"

    const val EVENT_UPDATE_SELF = "event_update_self"
    const val EVENT_UPDATE_USER_SUFFIX = "/info"

    const val IS_BLACK_THEME = "isBlack"
    const val TARGET_LANGUAGE = "target_language"
    const val APP_LANGUAGE = "app_language"
    const val MSG_STYLE = "message_style"
    const val EXTEND_STYLE = "extend_style"

    const val FEATURES_TRANSLATION = "features_translation"
    const val FEATURES_THREAD = "features_thread"
    const val FEATURES_REACTION = "features_reaction"
    const val FEATURES_SEND_ORIGINAL_IMAGE = "features_send_original_image"

    const val IS_TYPING_ON = "isTyping"

    const val PRESENCE_ONLINE = "Online"
    const val PRESENCE_BUSY = "Busy"
    const val PRESENCE_DO_NOT_DISTURB = "Do Not Disturb"
    const val PRESENCE_AWAY = "Away"

    const val DEMO_STOP_RECORD = "demo_stop_record"
}
